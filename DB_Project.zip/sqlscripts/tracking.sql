/*
    Returns Origin City Name
*/
-- SELECT Name AS Origin FROM PostOffice po
-- INNER JOIN City c
-- ON c.City_ID = po.City_ID
-- WHERE PostalCode = (
--     SELECT PostalCode FROM Invoice
--     WHERE Invoice_ID = (
--         SELECT Invoice_ID FROM Mail_Invoice
--         WHERE Barcode = 40001924
--     )
-- );

/*
    Returns Destion City
*/
-- SELECT Name AS Destination FROM City
-- WHERE City_ID = (
--     SELECT City_ID FROM DomesticAddresses
--     WHERE Address_ID = (
--         SELECT R_Address_ID FROM Mail
--         WHERE Barcode = 40001924
--     )
-- );


/*
    Invoice_Date
*/
-- SELECT Invoice_Date AS BookDate FROM Invoice
-- WHERE Invoice_ID = (
--     SELECT Invoice_ID FROM Mail_Invoice
--     WHERE Barcode = 40001924
-- );


/*
    Shipper
*/
-- SELECT FirstName || ' ' || LastName AS Shipper FROM Details
-- WHERE Details_ID = (
--     SELECT S_Detail_ID FROM Mail
--     WHERE Barcode = 40001924
-- );

/*
    Cosignee
*/
-- SELECT FirstName || ' ' || LastName AS Cosignee FROM Details
-- WHERE Details_ID = (
--     SELECT R_Detail_ID FROM Mail
--     WHERE Barcode = 40001924
-- );



/*
    Tracking History
*/

-- SELECT st.TimeStamp, stype.Description, c.Name FROM StatusTracking st 
-- INNER JOIN StatusType stype
-- ON st.Status_ID = stype.Status_ID
-- INNER JOIN PostOffice po
-- ON po.PostalCode = st.PostalCode
-- INNER JOIN City c
-- ON c.City_ID = po.City_ID
-- WHERE st.Barcode = 40001924
-- ORDER BY SerialNo desc;

/*
    Current Status
*/
SELECT  Description, TimeStamp FROM
(
    SELECT Description, TimeStamp, row_number() OVER (ORDER BY SerialNo DESC) AS rn FROM StatusTracking st
    INNER JOIN StatusType s
    ON st.Status_ID = s.Status_ID
    WHERE Barcode = 40001923
)
WHERE rn = 1;